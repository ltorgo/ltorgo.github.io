########################################
# Classification EDP Functions
########################################

# install packages
#library(caret) #confusion Matrix
library(datasets)
library(randomForest)
library(dplyr)
library(ggplot2)
library(reshape2)
library(RColorBrewer)
library(gtable)
library(gridExtra)


#############
## Bins data in respect to values of a predictor variable
## Input: dataset (data set, feature_x (name of predictor to bin values), 
##        nquant, size, quantil_break, breaks, nround (rounding digits)
## Options: nquant - choose number of bins equally frequent
##        : size - choose number of instances per bin
##        : quantil_break - choose quantile (unique) values
##        : breaks - choose break points
## Output: List of dataframes with indexes informing on the limits of each bin for the predictor variable

bin_data <- function(dataset, feature_x, nquant=NULL, size=NULL, quantil_break=c(0.1, 0.35, 0.65, 0.9), breaks=NULL, nround = 2){
  dataset <- dataset[order(dataset[[feature_x]]),]
  
  if (! is.null(size)){
    cutdata <- split(dataset, ceiling(seq_along(dataset[[feature_x]])/size))
  }
  else if(! is.null(nquant)){
    cutdata <- split(dataset, floor(nquant*seq.int(0, nrow(dataset) -1 )/ nrow(dataset)))
    
  }
  else{
    cutdata <- list()
    if (is.null(breaks))  breaks <- c(min(dataset[[feature_x]], na.rm=TRUE),
                                      quantile(unique(dataset[[feature_x]]),na.rm=TRUE,probs = quantil_break), 
                                      max(dataset[[feature_x]], na.rm=TRUE)+1)
    for (i in 1:(length(breaks)-1)){
      cutdata[[i]]<-data.frame()
      for (j in 1:nrow(dataset)){
        if (!is.na(dataset[[feature_x]][j])&&dataset[[feature_x]][j]>=breaks[[i]]&&dataset[[feature_x]][j]<breaks[[i+1]]){
          cutdata[[i]]<-rbind(cutdata[[i]], dataset[j,])
        }
      }
      
    }
  }
  
  # Check the existence of null bins. Calculate min and max of each bin
  cutdata<-cutdata[sapply(cutdata, function(x) dim(x)[1]) > 0]
  limit <- data.frame(featmax=0, featmin=0)
  for (i in 1:length(cutdata)) {
    limit[i,] <- c(max(cutdata[[i]][[feature_x]]), min(cutdata[[i]][[feature_x]]))
  }
  
  # Name bins with [lower limit - higher limit]. Increases nround if bins have same name due to few rounding numbers (ex [0-0], [0-0] --> [0-0.1],[0.1-0.2])
  repeat{
    names(cutdata)<-paste0("[",round(limit$featmin,nround), "-", round(limit$featmax,nround),"]")
    nround <- nround+1
    if (length(names(cutdata))==length(unique(names(cutdata)))){
      break
    }
  }
  
  if(!all(!is.na(dataset[[feature_x]]))){
    cutdata[["NA"]] <- dataset[is.na(dataset[[feature_x]]),]
  }
  return (cutdata)
}


################
## Prepares data set for required format, for single model
## Input: data (all observations, with n variables and the observed target), 
## pred (vector with model prediction), target (name of target variable),
## details ("show_all" or "reduced" - presents entire information about misclassification,
## or only which category did the model fail to predict)
#
## Output: data set with all observations, and with columns
## [Var1 | ... | Varn | Target Observed | Predicted target]

prep_data <- function(data, pred, target, details = "show_all"){
  
  data <- cbind(data, data.frame("Prediction" = pred)) %>% mutate_if(is.factor, as.character)

  # Identify which predictions are expected to be correct, and if not, what was the mistake
  if(details == "show_all"){
  data$Prediction[which(data[, target] != data$Prediction)] <- paste0("Wrong - ",
                                                            data[which(data[, target] != data$Prediction), "Prediction"], 
                                                            " I/O ", data[which(data[, target] != data$Prediction), target])
  }
  else if(details == "reduced"){
    data$Prediction[which(data[, target] != data$Prediction)] <- paste0("Wrong - ",
                                                                        data[which(data[, target] != data$Prediction), target])
  }
  
  else{
    cat("The variable details should be assigned to value 'reduced' or 'show_all'\n")
    }
  
  data$Prediction[which(data[, target] == data$Prediction)] <- "Correct"

  data[] <- data %>% lapply(type.convert, as.is = FALSE)  
  return(data)
}


#############
## Creates EDP for categorical predictions
## Input: dataset (data set, feature_x (name of predictor to bin values), 
##        bin_data options (nquant, size, quantil_break, breaks, nround (rounding digits))
## Options: nquant - choose number of bins equally frequent
##        : size - choose number of instances per bin
##        : quantil_break - choose quantile (unique) values
##        : breaks - choose break points
##        : zoom - displays close up of error, below the EDP
cep <- function(dataset, feature_x, nquant=NULL, size=NULL, quantil_break=c(0.1, 0.35, 0.65, 0.9), breaks=NULL, nround = 2, zoom = TRUE){

  if(n_distinct(dataset$Prediction) > 10){
    color <- colorRampPalette(brewer.pal(9, "Set1"))(n_distinct(dataset$Prediction) - 1)
  } else{
    color <- suppressWarnings(brewer.pal(n_distinct(dataset$Prediction)-1, "Set1"))
  }
  
   
  # nominal feature (does not need partition)
  if(is.factor(dataset[[feature_x]])){
     freq <- plyr::count(dataset[[feature_x]])
      nbins <- length(freq[[1]])
      plot <-  ggplot(dataset) + geom_bar(aes_string(x = feature_x, fill = "Prediction"),
                                                position = "fill") + xlab(feature_x) +
      scale_fill_manual(values = c("gray", color)) +
      guides(fill = FALSE) +  
      scale_y_continuous(labels = scales::percent) +
      ylab("Percentage") +
      scale_x_discrete(labels=paste0(freq[[1]],"\n(",round(freq[["freq"]]*100/nrow(dataset),2),"% - ",freq[["freq"]], ")"))
      
      if(zoom){
        erfreq <- data.frame("x" = factor(levels(dataset[[feature_x]])))
        erfreq <- plyr::count(factor(dataset[[feature_x]][-which(dataset$Prediction == "Correct")])) %>% right_join(erfreq, warning = FALSE)
        erfreq$perc <- round(erfreq[[2]]*100/length(which(dataset$Prediction != "Correct")), 2)
        erfreq[is.na(erfreq)] <- 0
        
        erplot <- ggplot(filter(dataset, Prediction != "Correct")) +
          geom_bar(aes_string(x = feature_x, fill = "Prediction"), position = "fill") + xlab(feature_x) +
          scale_fill_manual(values = color) +
          guides(fill = FALSE) +
          scale_y_continuous(labels = scales::percent) +
          ylab("Errors") +
          scale_x_discrete(labels=paste0("(", erfreq$perc, "% - ", erfreq$freq, ")\n "), drop = FALSE)
      }
      }
  
  
  
  else{
    cutdata <- bin_data(dataset, feature_x, nquant, size, quantil_break, breaks, nround)
    nbins <- length(cutdata)
    bins <- names(cutdata)
    cutdata <- reshape2::melt(cutdata, id.vars=feature_x, measure.vars="Prediction", value.name="Prediction")
    cutdata$L1 <- factor(cutdata$L1, levels=bins)
    
    freqcount <- plyr::count(factor(cutdata$L1))[[2]]
    freq <- round(freqcount*100/nrow(dataset), 2)
    
    #2. create plot
    plot <- ggplot(cutdata) + geom_bar(aes(x = L1, fill = Prediction),
                            position = "fill") + xlab(feature_x) +
     scale_fill_manual(values = c("gray", color)) +
      guides(fill = FALSE) +
    scale_y_continuous(labels = scales::percent) +
    ylab("Percentage") + 
      scale_x_discrete(labels=paste0(bins, "\n(", freq, "% - ", freqcount, ")"))
   
    if(zoom){
      erfreq <- data.frame("x" = factor(levels(cutdata$L1)))
      erfreq <- plyr::count(factor(cutdata$L1[-which(cutdata$Prediction == "Correct")])) %>% right_join(erfreq)
      erfreq$perc <- round(erfreq[[2]]*100/length(which(cutdata$Prediction != "Correct")), 2)
      erfreq[is.na(erfreq)] <- 0
       
      erplot <- ggplot(filter(cutdata, Prediction != "Correct")) +
        geom_bar(aes(x = L1, fill = Prediction), position = "fill") + xlab(feature_x) +
        scale_fill_manual(values = color) +
        guides(fill = FALSE) +
        scale_y_continuous(labels = scales::percent) +
        ylab("Errors") +
        scale_x_discrete(labels=paste0("(", erfreq$perc, "% - ", erfreq$freq, ")\n "), drop = FALSE)
      
      # ymax <- max(erfreq)
      # erplot <- ggplot(cutdata) + geom_bar(aes(x = L1, fill = Prediction),
      #                                    position = "fill") +
      #   scale_fill_manual(values = c("gray", color)) +
      #   guides(fill = FALSE) +
      #   scale_y_continuous(labels = scales::percent) +
      #   ylab("Percentage") + coord_cartesian(ylim=c(0,0.01*ymax)) + xlab(feature_x)
    }
      
  }
  
  allerror <- ggplot(dataset)+ xlab(" ") + geom_bar(aes(x = "all", fill = Prediction),
                                             position = "fill") +
    scale_fill_manual(name = "Expected Prediction", values = c("gray", color)) +
    scale_x_discrete(labels=paste0("All data \n(100% - ",nrow(dataset), ")")) + 
    theme(axis.text.y = element_blank(),  axis.ticks.y = element_blank(), axis.title.y=element_blank()) +
    theme(legend.position="top", legend.title = element_text(size = 8), legend.text = element_text(size = 8)) +
  guides(fill = guide_legend(override.aes = list(size = 1)))
  
  if(zoom){
    allerror2 <- ggplot(filter(dataset, Prediction != "Correct"))+
      geom_bar(aes(x = "all", fill = Prediction), position = "fill") +
      scale_fill_manual(name = "Expected Prediction", values = color) +
      theme(axis.text.y = element_blank(), axis.ticks.y = element_blank(), axis.title.y=element_blank()) +
      theme(legend.position="top", legend.title = element_text(size = 8), legend.text = element_text(size = 8)) +
      guides(fill = FALSE) + xlab(" ") +
      scale_x_discrete(labels = paste0("All errors \n(100% - ", sum(dataset$Prediction != "Correct"), ")"))
    
    # allerror2 <- ggplot(dataset)+ xlab(" ") + geom_bar(aes(x = "all", fill = Prediction),
    #                                                                position = "fill") +
    #   scale_fill_manual(name = "Expected Prediction", values = c("gray", color)) +
    #   scale_x_discrete(labels=paste0("All data")) + 
    #   theme(axis.text.y = element_blank(),  axis.ticks.y = element_blank(), axis.title.y=element_blank()) +
    #   theme(legend.position="top", legend.title = element_text(size = 8), legend.text = element_text(size = 8)) +
    #   guides(fill = FALSE) + xlab(" ") + coord_cartesian(ylim=c(0,0.01*ymax))
  }
  
   
  legend <- gtable_filter(ggplot_gtable(ggplot_build(allerror)), "guide-box")
  
  if(!zoom){
    plot <- grid.arrange(arrangeGrob(plot + theme(legend.position="none"),
                             allerror + theme(legend.position="none"),
                             nrow = 1, widths = c(nbins,1)),
                 legend,
                 heights=c(1,0.1*ceiling(length(color)/10)), #heights=c(1.1,0.1*ceiling(length(color)/20)),
                 nrow = 2) # , respect = TRUE??
  }else{
  
  plot <- grid.arrange(arrangeGrob(plot + theme(legend.position="none") + xlab(""),
                                   allerror + theme(legend.position="none"),
                                   erplot + theme(legend.position="none"),
                                   allerror2 + theme(legend.position="none"),
                                   nrow = 2, widths = c(nbins,1), heights = c(3,1)),
                       legend,
                       heights=c(2,0.1*ceiling(length(color)/10)), #heights=c(1.1,0.1*ceiling(length(color)/20)),
                       nrow = 2) # , respect = TRUE??
  }
 
  return(plot)
}


#plot_grid(grid.arrange(arrangeGrob(plot + theme(legend.position="none"),
#allerror + theme(legend.position="none"),
#nrow = 1, widths = c(nbins,1)), legend, ncol = 1, align = "v", rel_heights = c(3,0.1*ceiling(length(color)/20))
