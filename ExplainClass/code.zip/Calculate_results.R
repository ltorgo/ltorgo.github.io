source('Functions_ClassificationEDP.R')

load("benchmarkWithPreds.Rdata")
y_names <- DSOut[[19]]
DSOut <- DSOut[1:18]

for(d in 1:length(DSOut)){
  
  
  data_set  <- DSOut[[d]][complete.cases(DSOut[[d]][, which(names(DSOut[[d]]) %in% c("svm","randomForest", "nnet", "naiveBayes"))]),] #include only cases where CV estimates were calculated

  for (mod in c("svm","randomForest", "nnet", "naiveBayes")){
    plots <- list()
    db <- prep_data(data_set[,-which(names(data_set) %in% c("svm","randomForest", "nnet", "naiveBayes"))], data_set[, mod], y_names[[d]]) 
    if(d==1){db[]<- db %>% lapply(as.factor)}
    for (feat in names(db)[-c(ncol(db), which(names(db) == y_names[[d]]))]){
      plots[[feat]] <-  cep(db, feat)
    }
    g1 <- marrangeGrob(grobs=plots, ncol=2, nrow=4)
    ggsave(paste0("Results/",names(DSOut)[[d]],"_", mod,"_Cat.pdf"),g1,width=15,height=20)
    
  }
}

for(d in 1:length(DSOut)){
  
  
  data_set  <- DSOut[[d]][complete.cases(DSOut[[d]][, which(names(DSOut[[d]]) %in% c("svm","randomForest", "nnet", "naiveBayes"))]),] #include only cases where CV estimates were calculated
  # 
  for (mod in c("svm","randomForest", "nnet", "naiveBayes")){
    plots <- list()
    db <- prep_data(data_set[,-which(names(data_set) %in% c("svm","randomForest", "nnet", "naiveBayes"))], 
                    data_set[, mod], y_names[[d]],
                    details = "reduced") 
    for (feat in names(db)[-c(ncol(db), which(names(db) == y_names[[d]]))]){
      plots[[feat]] <-  cep(db, feat)
    }
    g1 <- marrangeGrob(grobs=plots, ncol=2, nrow=4)
    ggsave(paste0("Results/",names(DSOut)[[d]],"_", mod,"_ReducedCat.pdf"),g1,width=15,height=20)
    
  }
}


# OPTION TO ORDER BY MOST PREVALENT ???

