suppressMessages(library(dplyr))
suppressMessages(library(GGally))
suppressMessages(library(plyr))
suppressMessages(library(gridExtra))
suppressMessages(library(reshape2))

### Calculates the error between observed and predicted feature
### Input: y (observed y), ypred (predicted y) , type (type of error: "Absolute", "Residual" or "Log")
calculate_error <- function(y, ypred, type="Absolute"){
  if (type == "Absolute") {
    error <- abs(y-ypred)
  }
  if (type == "Residual"){
    error <- y-ypred
  }
  #Adds 1 for the visualization to start at 0
  if (type == "Log"){
    error <- log(1+abs(y-ypred))
  }
  return (error)  
}  

#############
## Creates a data frame with feature values, SINGLE model error and model prediction
## Format: variable1|...|variablen| ypred| error
## Size: n_data_points x (n_features + 2)
## Input: data (data set with features and predictor), model (model prediction)
##        type (error type:"Absolute", "Residual" or "Log")
single_model_data <- function (data, model, feature_y, type="Absolute"){
  y <- data[[feature_y]]
  x <- data[,names(data) != feature_y]
  ypred <- model
  x$pred <- ypred
  x$error <- calculate_error(y, ypred, type)
  return (x)
}

#############
## Bins data in respect to values of a predictor variable
## Input: dataset (data set of type single_model_data() or all_model_data()), feature_x (name of predictor to bin values), 
##        nquant, size, quantil_break, breaks, nround (rounding digits), for_evaluation (if FALSE deletes empty bins)
## Options: nquant - choose number of bins equally frequent
##        : size - choose number of instances per bin
##        : quantil_break - choose quantile values
##        : breaks - choose break points
## return_breaks: if TRUE, gives break points for train and test set (to be used in evaluation only) as well as the bins names
## Output: List of dataframes with indexes informing on the limits of each bin for the predictor variable
bin_data <- function(dataset, feature_x, nquant=NULL, size=NULL, quantil_break=c(0.1, 0.35, 0.65, 0.9), breaks=NULL, nround=2, for_evaluation=FALSE, return_breaks=FALSE){
  dataset <- dataset[order(dataset[[feature_x]]),]
  
  if (! is.null(size)){
    cutdata <- split(dataset, ceiling(seq_along(dataset[[feature_x]])/size))
  }
  else if(! is.null(nquant)){
    cutdata <- split(dataset, floor(nquant*seq.int(0, nrow(dataset) -1 )/ nrow(dataset)))
    
  }
  else{
    cutdata <- list()
    if (is.null(breaks))  breaks <- c(min(dataset[[feature_x]]),quantile(unique(dataset[[feature_x]]),probs = quantil_break), max(dataset[[feature_x]])+1)
    for (i in 1:(length(breaks)-1)){
      cutdata[[i]]<-data.frame()
      for (j in 1:nrow(dataset)){
        if (dataset[[feature_x]][j]>=breaks[[i]]&&dataset[[feature_x]][j]<breaks[[i+1]]){
          cutdata[[i]]<-rbind(cutdata[[i]], dataset[j,])
        }
      }
    }
  }
  
  if(isFALSE(for_evaluation)){
    # Check the existence of null bins. Calculate min and max of each bin
    cutdata<-cutdata[sapply(cutdata, function(x) dim(x)[1]) > 0]
    limit <- data.frame(featmax=0, featmin=0)
    for (i in 1:length(cutdata)) {
      limit[i,] <- c(max(cutdata[[i]][[feature_x]]), min(cutdata[[i]][[feature_x]]))
    }
    
    # Name bins with [lower limit - higher limit]. Increases nround if bins have same name due to few rounding numbers (ex [0-0], [0-0] --> [0-0.1],[0.1-0.2])
    repeat{
      names(cutdata)<-paste0("[",round(limit$featmin,nround), "-", round(limit$featmax,nround),"]")
      nround <- nround+1
      if (length(names(cutdata))==length(unique(names(cutdata)))){
        break
      }
    }
  }
  
  if(isTRUE(return_breaks)){
    result <- list(breaks=c(limit$featmin, tail(limit$featmax, n=1)+1), names = names(cutdata))
    return(result)
  }else{
    return (cutdata)}
}  


#############
## ERROR DISTRIBUTION PLOT (EDP)
## Input: data (data set of type single_model_data()), feature (feature of interest, x-axis), 
##        bin_data options (nquant, size, quantil_break, breaks), nround (rounding digits), 
##        type (error type), jitter
edp <- function(data,  feature, nquant=NULL, size=NULL, quantil_break=c(0.1, 0.35, 0.65, 0.9), breaks=NULL, jitter=FALSE, nround=2, type="Absolute"){
  
  errorplot <- ggplot() +
    xlab(feature) + ylab(paste0(type, " error distribution"))
  
  # EDP for nominal feature (does not need partition)
  if(is.factor(data[[feature]])){
    freq <- plyr::count(factor(data[[feature]]))
    nbins <- length(freq[[1]])
    errorplot <- errorplot + geom_boxplot(data=data, aes(x=data[[feature]], y=error)) + scale_x_discrete(labels=paste0(freq[[1]],"\n(",round(freq[["freq"]]*100/nrow(data),2),"% - ",freq[["freq"]], ")")) + geom_hline(yintercept=median(data[["error"]]), linetype="dashed")
    if (isTRUE(jitter)){ 
      errorplot<-errorplot + geom_jitter(data=data, aes(x=data[[feature]], y=error), alpha= 0.3)
    }
  }
  
  # EDP for numerical feature (with partition of data set into bins)
  else{
    cutdata <- bin_data(data, feature, nquant=NULL, size=NULL, quantil_break=c(0.1, 0.35, 0.65, 0.9), breaks=NULL)
    nbins <- length(cutdata)
    var <- melt(cutdata, id.vars=feature, measure.vars="error", value.name="error")
    freqcount <- plyr::count(factor(var$L1))[[2]]
    freq <- round(freqcount*100/nrow(data), 2)
    var$L1 <- factor(var$L1, levels=names(cutdata))
    
    errorplot <- errorplot + geom_boxplot(data=var, aes(x=L1, y=error))+ 
      scale_x_discrete(labels=paste0(names(cutdata), "\n(", freq, "% - ", freqcount, ")")) +
      geom_hline(yintercept=median(data[["error"]]), linetype="dashed")
    
    if (isTRUE(jitter)){ 
      errorplot <- errorplot + geom_jitter(data=var, aes(x=L1, y=error), alpha= 0.3)
    }
  }
  
  # Adds comparison plot with all data
  allerror <- ggplot()+ xlab(" ") + geom_boxplot(data=data, aes(x='all', y=error)) + scale_x_discrete(labels=paste0("All data \n(100% - ",nrow(data), ")")) + theme(axis.text.y = element_blank(),  axis.ticks.y = element_blank(), axis.title.y=element_blank())  + geom_hline(yintercept=median(data[["error"]]), linetype="dashed") 
  plot <- grid.arrange(errorplot, allerror, ncol=2, widths=c(nbins, 1))
  return(plot)
}

#############
## BIVARIATE ERROR DISTRIBUTION PLOT
## Input: data (data set of type single_model_data()), feature_list (list of features - first is the x axis, second has the bins as the conditioning)
##        quantil_break, nround (rounding digits), type (error type),
##        option (type of data without conditioning to show in first facet),
##        mode (wrap or grid), ncols (number of columns in final plot)
## Option: 1 - Shows EDP of 1rst variable in feature_list 
##         2 - Shows EDP of 2nd variable in feature_list 
##         "All" - Shows total error distribution
## Mode (only for 3 variables): grid (matrix type; plots all combinations, even if empty; without comparison plot)
##                            : wrap (only plots existing combinations; single plots juxtaposed; with comparison plot)
multiple_edp <- function(data, feature_list, quantil_break=c(0.1, 0.35, 0.65, 0.9), nround=2, type="Absolute", option="All", mode="grid", ncols=2){
  
  var <- melt(data, id.vars=feature_list, measure.vars="error", value.name="error")
  var["variable"] <- NULL
  
  for (f in 1:length(feature_list)){
    if(!is.factor(data[[feature_list[[f]]]])){
      cutdata <- bin_data(var, feature_list[[f]], quantil_break=quantil_break)
      var <- melt(cutdata, id.vars=feature_list, measure.vars="error", value.name="error")
      var[[feature_list[[f]]]]<-factor(var[["L1"]], levels=names(cutdata))
      var[c("L1", "variable")]<-NULL
    }
    if (f != 1){
      var[[feature_list[[f]]]]<-mapvalues(var[[feature_list[[f]]]], from = levels(var[[feature_list[[f]]]]), to = paste0(feature_list[[f]], " = ", levels(var[[feature_list[[f]]]])))
    }
  }
  
  var<-merge(var,plyr::count(var, feature_list))
  var$median <- median(data[["error"]])
  
  if ((nlevels(var[[feature_list[[2]]]]) >= ncols) & (mode == "wrap" || length(feature_list)==2)){
    #Fake point to allow plotting comparison graph
    var[[feature_list[[2]]]] <- factor(var[[feature_list[[2]]]], levels=c(" ", levels(var[[feature_list[[2]]]]))) 
    var <- rbind(var, var[1,])
    var[[feature_list[[2]]]][nrow(var)] <- " "
  }
  
  
  errorplot <- ggplot(data=var, aes_string(x=feature_list[1], y="error")) + geom_boxplot() +
    geom_text(aes(label=paste0(freq," (",round(100*var$freq/nrow(data),2),"%)"), y=0-max(var$error)/40), vjust=1, size=3) +
    geom_hline(aes(yintercept=median), linetype="dashed")
  
  if (mode == "grid"){
    gtable <- errorplot + facet_grid(feature_list[-1])
    
  }else if (mode == "wrap" || length(feature_list)==2){
    
    errorplot <- errorplot + facet_wrap(feature_list[-1], ncol=ncols, drop=TRUE, scales='free') + 
      geom_blank(aes(y=max(var$error))) +
      theme(axis.title.x=element_blank(), axis.title.y=element_blank(), axis.ticks.x = element_blank())
    
    #Eliminate 1rst fake plot and substitute by one for comparison
    errorplot <- ggplotGrob(errorplot)
    if (nlevels(var[[feature_list[[2]]]]) >= ncols){
    rm_grobs <- errorplot$layout$name %in% c("panel-1-1",  "strip-t-1-1", "axis-l-1-1", "axis-b-1-1", "axis-r-1-1")
    errorplot$grobs[rm_grobs] <- NULL
    errorplot$layout <- errorplot$layout[!rm_grobs, ]
    }
    
    ext = ifelse(length(feature_list)==2, "", " \n ")
    
    #Plot Comparison Facet
    if(option=='All'){
      plot1 <- ggplot(data=var, aes(x='All data', y=error)) + geom_boxplot() +
        geom_text(aes(label=paste0(nrow(data)," (100%)"), y=0-max(var$error)/40), vjust=1, size=3) +
        geom_hline(aes(yintercept=median), linetype="dashed") +
        theme(axis.title.x=element_blank(), axis.title.y = element_blank(), axis.ticks.x = element_blank()) + facet_wrap(~paste0(ext, "All data", ext)) +
        geom_blank(aes(y=max(var$error)))
      
    }else{
      var$freq<-NULL
      var<-merge(var,plyr::count(var, feature_list[option]))
      
      plot1 <- ggplot(data=var, aes_string(x=feature_list[option], y="error")) + geom_boxplot() +
        geom_text(aes(label=paste0(freq," (",round(100*freq/nrow(data),2),"%)"), y=0-max(var$error)/40), vjust=1, size=3) +
        geom_hline(aes(yintercept=median), linetype="dashed") +
        theme(axis.title.x=element_blank(), axis.title.y=element_blank(), axis.ticks.x = element_blank()) + facet_wrap(~paste0(ext, "All data", ext))
    }
    
    nrows <- (nrow(plyr::count(var, feature_list[-1]))-1) %/% ncols + 1
    mat <- matrix(c(2, rep(c(1), nrows*ncols-1)), ncol=ncols)
    gtable <- arrangeGrob(errorplot, plot1, layout_matrix=mat, left=paste0(type, " error distribution"), bottom=feature_list[[1]])
  }
  return (gtable)
}

