source("performance_functions.R")

load("dataSetsWithPreds.Rdata")
names(DSsPreds) <- c('a1','a2','a3','a4','a6','a7','Abalone','acceleration','availPwr','bank8FM','cpuSm','fuelCons','boston','maxTorque','machineCpu','servo','airfoild','concreteStrength')
err <- "Absolute"
nmod <- 4

#Single Model Analysis
option="All"
for (j in 1:length(DSsPreds)) { 
  data_set  <- DSsPreds[[j]][complete.cases(DSsPreds[[j]]),]
  y_observed <- names(data_set)[1]
  for (mod in c("svm","randomForest", "nnet", "gbm")){
  
    single_error_ds <- single_model_data(data=data_set[1:(length(data_set) - nmod)], model=data_set[[mod]], feature_y=names(data_set)[1], type=err)

    plots2 <- list()
    for (i in 2:(ncol(data_set)-nmod)){
      x_feature <- names(data_set)[i]
      plots2[[i-1]]<-edp(single_error_ds, x_feature, type=err, jitter=FALSE)
    }
    g1 <- marrangeGrob(grobs=plots2, ncol=2, nrow=4)
    ggsave(paste0("EDP/",names(DSsPreds)[[j]],"_", mod,"_EDP_",err,".pdf"),g1,width=15,height=20)

    comb<-combn(names(data_set[2:(length(data_set) - nmod)]),2)[,]
    plots3 <- list()
    for (c in 1:ncol(comb)) {
       plots3[[c]]<-multiple_edp(single_error_ds, comb[,c], type=err, option='All', ncols=3, mode="wrap")
    }
    g2 <- marrangeGrob(grobs=plots3, ncol=1, nrow=2)
    ggsave(paste0("EDP_Bivariate/BivEDP_",err,"_",names(DSsPreds)[[j]],"_",mod,".pdf"),g2,width=15,height=20)

  }
 
}
