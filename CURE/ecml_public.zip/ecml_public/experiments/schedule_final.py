import sys
import os

sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

import databases
import datasets


for n_minority_train_samples in [50, 30, 10]:
	for dataset in datasets.names('final'):
		for fold in range(1, 11):
			for alpha in [0.05]:
				for sd in [1.15]:
					for beta in [0.5]:
						trial = {
							'Algorithm': 'CURE',
							'Parameters': {
								'alpha': alpha,
								'beta': beta,
								'useRadius': False,
								'std': sd
							},
							'Dataset': dataset,
							'Fold': fold,
							'MinSmp': n_minority_train_samples,
							'Description': 'Final'
						}
						print(trial)
						databases.add_to_pending(trial)
			for algorithm in ['SMOTE','SMOTE+TL','Bord','ADASYN']:
				for k in [9]:
					trial = {
						'Algorithm': algorithm,
						'Parameters': {
							'beta': 0.5,
							'k': k
						},
						'Dataset': dataset,
						'Fold': fold,
						'MinSmp': n_minority_train_samples,
						'Description': 'Final'
					}
					print(trial)
					databases.add_to_pending(trial)
			for algorithm in ['SMOTE+TL']:
				for k in [9,12]:
					trial = {
					'Algorithm': algorithm,
						'Parameters': {
							'beta': 0.5,
							'k': k
						},
						'Dataset': dataset,
						'Fold': fold,
						'MinSmp': n_minority_train_samples,
						'Description': 'Final'
					}
					print(trial)
					databases.add_to_pending(trial)
			for algorithm in ['Bord']:
				for k in [3, 5, 7, 9]:
					for m in [8, 10, 12]:
						trial = {
						'Algorithm': algorithm,
							'Parameters': {
								'beta': 0.5,
								'k': k,
								'm': m,
							},
							'Dataset': dataset,
							'Fold': fold,
							'MinSmp': n_minority_train_samples,
							'Description': 'Final'
						}
						print(trial)
						databases.add_to_pending(trial)
			for algorithm in ['ROS', 'RUS', 'RUS+ROS']:
			  for beta in [0.5]:
			    trial = {
			      'Algorithm': algorithm,
			      'Parameters': {
			        'beta':beta
			      },
			      'Dataset': dataset,
			      'Fold': fold,
			      'MinSmp': n_minority_train_samples,
			      'Description': 'Final'
			    }
			    # print(trial)
			    databases.add_to_pending(trial)
			for algorithm in ['None']:
			  trial = {
			    'Algorithm': algorithm,
			    'Parameters': {
			      'None':None
			    },
			    'Dataset': dataset,
			    'Fold': fold,
			    'MinSmp': n_minority_train_samples,
			    'Description': 'Final'
			  }
			databases.add_to_pending(trial)

