# CURE: ClUster REsampling

This could can be used to reproduce the experiments reported in Paper 910 submitted for consideration at ECML PKDD 2019

# Usage

Tested on Python 2.7.9.

To download all of the necessary datasets:

```python datasets.py```

To initialize the databases:

```python databases.py```

To schedule the experiments associated with the [preliminary|final] analysis:

```python experiments/schedule_final.py```

To start a runner, pulling unfinished trials until there are none left (note that several runners can operate simultaneously):

```python run.py```

To export the results from a previously initialized database into a CSV file:

```python databases.py```



*** This is experimental framework is based on the framework published inconjection with:

Koziarski, Michal, Bartosz Krawczyk, and Michal Woźniak. "Radial-Based oversampling for noisy imbalanced data classification." Neurocomputing (2019).