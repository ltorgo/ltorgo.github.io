import numpy as np
import multiprocessing as mp
from databases import pull_pending, submit_result
from datasets import loadSynth
from collections import Counter
from sklearn import metrics
from sklearn.svm import SVC as SVM
from imblearn.over_sampling import ADASYN, SMOTE
from imblearn.combine import SMOTEENN, SMOTETomek
from cure import Cure
from imblearn.over_sampling import RandomOverSampler as ROS
from imblearn.under_sampling import RandomUnderSampler as RUS
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import RandomizedSearchCV
from imblearn.pipeline import Pipeline
from imblearn.over_sampling import BorderlineSMOTE

N_PROCESSES = 5


def run():
	while True:
		trial = pull_pending()
		if trial is None:
			print("no more trails to pull")
			break
		params = eval(trial['Parameters'])
		print(params)
		print(trial)       
		if trial['Algorithm'] == 'CURE':
			algorithm = Cure()
		elif (trial['Algorithm'] is None) or (trial['Algorithm'] == 'None'):
			algorithm = None
		elif trial['Algorithm'] == 'ROS':
			algorithm = ROS()
		elif trial['Algorithm'] == 'RUS':
			algorithm = RUS()
		elif trial['Algorithm'] == 'RUS+ROS':
			a1 = RUS()
			a2 = ROS()
			c  = SVM()
			alorithm = Pipeline([('rus', a1), ('ros', a2), ('svm', c)])
		elif trial['Algorithm'] == 'SMOTE+TL':
			algorithm = SMOTETomek(smote=SMOTE(k_neighbors=params['k']))
		elif trial['Algorithm'] == 'SMOTE+ENN':
			algorithm = SMOTEENN(smote=SMOTE(k_neighbors=params['k']))
		elif trial['Algorithm'] == 'SMOTE':
			algorithm = SMOTE(k_neighbors=params['k'])
		elif trial['Algorithm'] == 'Bord':
			algorithm = SMOTE(kind='borderline1',k_neighbors=params['k'])
		elif trial['Algorithm'] == 'ADASYN':
			algorithm = ADASYN(n_neighbors=params['k'])
		
		minSize = int(trial['MinSmp'])
		dataset = loadSynth(trial['Dataset'], minSize=minSize)
		fold = int(trial['Fold']) - 1

		(X_train, y_train), (X_test, y_test) = dataset[fold][0], dataset[fold][1]
		minCls = np.argmin(np.bincount(y_train.astype(int)))
		majCls = np.argmax(np.bincount(y_train.astype(int)))
		minSize = np.sum(y_train==minCls)
		majSize = np.sum(y_train==majCls)

		labels = np.unique(y_test)
		counts = [len(y_test[y_test == label]) for label in labels]
		minority_class = labels[np.argmin(counts)]
		if  algorithm.__class__ in [Cure]:
			algorithm.fit(X_train, y_train, alpha=params['alpha'], stds=params['std'])
			newMajSize = np.round((params['beta']) * majSize)
			newMinSize = minSize + np.round((1-params['beta']) * majSize)
			newMinSize = np.min([newMinSize, newMajSize])
			X_train, y_train = algorithm.resample(rsmpldSize=dict({majCls:newMajSize.astype(int), minCls:newMinSize.astype(int)}))
		elif algorithm.__class__ in [SMOTEENN, SMOTETomek]:
			newMajSize = np.round((params['beta']) * majSize)
			newMinSize = minSize + np.round((1-params['beta']) * majSize)
			newMinSize = np.min([newMinSize, newMajSize])
			rus = RUS(sampling_strategy=dict({majCls:newMajSize.astype(int), minCls:minSize.astype(int)}), random_state=423543)
			X_train, y_train = rus.fit_sample(X_train, y_train)
			algorithm.sampling_strategy = dict({majCls:newMajSize.astype(int), minCls:newMinSize.astype(int)})
			algorithm.smote.k_neighbors = np.min([minSize - 1, params['k']])
			try:
				X_train, y_train = algorithm.fit_sample(X_train, y_train)
			except ValueError:
				print("not samples generated")
		elif algorithm.__class__ in [SMOTE, BorderlineSMOTE]:
			newMajSize = np.round((params['beta']) * majSize)
			newMinSize = minSize + np.round((1-params['beta']) * majSize)
			newMinSize = np.min([newMinSize, newMajSize])
			rus = RUS(sampling_strategy=dict({majCls:newMajSize.astype(int), minCls:minSize.astype(int)}), random_state=423543)
			X_train, y_train = rus.fit_sample(X_train, y_train)
			algorithm.sampling_strategy = dict({majCls:newMajSize.astype(int), minCls:newMinSize.astype(int)})
			algorithm.k_neighbors = np.min([minSize - 1, params['k']])
			try:
				X_train, y_train = algorithm.fit_sample(X_train, y_train)
			except ValueError:
				print("not samples generated")
		elif algorithm.__class__ in [ADASYN]:
			newMajSize = np.round((params['beta']) * majSize)
			newMinSize = minSize + np.round((1-params['beta']) * majSize)
			newMinSize = np.min([newMinSize, newMajSize])
			rus = RUS(sampling_strategy=dict({majCls:newMajSize.astype(int), minCls:minSize.astype(int)}), random_state=423543)
			X_train, y_train = rus.fit_sample(X_train, y_train)
			algorithm.sampling_strategy = dict({majCls:newMajSize.astype(int), minCls:newMinSize.astype(int)})
			algorithm.n_neighbors = np.min([minSize - 1, params['k']])
			try:
				X_train, y_train = algorithm.fit_sample(X_train, y_train)
			except ValueError:
				print("not samples generated")
		elif algorithm.__class__ in [ROS]:
			newMinSize = minSize + np.round((1-params['beta']) * majSize)
			newMinSize = np.min([newMinSize, majSize])
			algorithm.sampling_strategy = dict({majCls:majSize, minCls:newMinSize.astype(int)})
			X_train, y_train = algorithm.fit_sample(X_train, y_train)
		elif algorithm.__class__ in [Pipeline]:
			newMajSize = np.round((params['beta']) * majSize)
			newMinSize = minSize + np.round((1-params['beta']) * majSize)
			newMinSize = np.min([newMinSize, newMajSize])
			a1 = ROS(majCls=majSize, minCls=newMinSize.astype(int))
			a2 = RUS(majCls=newMajSize.astype(int), minCls=minSize)
			X_train, y_train = a2.fit_sample(X_train, y_train)
			X_train, y_train = a1.fit_sample(X_train, y_train)
		elif algorithm.__class__ in [RUS]:
			newMajSize = np.round((params['beta']) * majSize)
			algorithm.sampling_strategy = dict({majCls:newMajSize.astype(int), minCls:minSize})
			X_train, y_train = algorithm.fit_sample(X_train, y_train)
		elif algorithm is not None:
			print(Counter(y_train))
		for clf in ['SVM']:
			param_dist = {"gamma": [0.001, 20],
			"C": [0.001, 20]}
			# run randomized search
			n_iter_search = 10
			random_search = RandomizedSearchCV(SVM(kernel='rbf'), param_distributions=param_dist, n_iter=n_iter_search, cv=5)
			random_search.fit(X_train, y_train)
			clfr = random_search
			predictions = clfr.predict(X_test)
			
			g_mean = 1.0

			for label in np.unique(y_test):
			    idx = (y_test == label)
			    g_mean *= metrics.accuracy_score(y_test[idx], predictions[idx])
			g_mean = np.sqrt(g_mean)
			print("g-mean: " + str(g_mean))
			scores = {
				'Accuracy': metrics.accuracy_score(y_test, predictions),
				'Average accuracy': np.mean(metrics.recall_score(y_test, predictions, average=None)),
				'Precision': metrics.precision_score(y_test, predictions, pos_label=minority_class),
				'Recall': metrics.recall_score(y_test, predictions, pos_label=minority_class),
				'F-measure': metrics.f1_score(y_test, predictions, pos_label=minority_class),
				'AUC': metrics.roc_auc_score(y_test, predictions),
				'G-mean': g_mean
			}
			trial['Algorithm'] = trial['Algorithm']+"_"+clf
			submit_result(trial, scores)

if __name__ == '__main__':
    for _ in range(N_PROCESSES):
        mp.Process(target=run).start()
