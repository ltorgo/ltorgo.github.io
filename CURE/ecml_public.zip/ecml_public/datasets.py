import os
import zipfile
import numpy as np
import pandas as pd
import pickle

from collections import Counter
from sklearn import preprocessing
from sklearn.model_selection import ShuffleSplit
from sklearn.preprocessing import MinMaxScaler
from sklearn.datasets import make_classification
from imblearn.datasets import make_imbalance
from sklearn.model_selection import RepeatedStratifiedKFold

try:
    from urllib.request import urlretrieve
except ImportError:
    from urllib import urlretrieve


DATA_PATH = os.path.join(os.path.dirname(__file__), 'data_synth')
FOLDS_PATH = os.path.join(os.path.dirname(__file__), 'folds_synth')
SYNTHETIC_DATA_PATH = os.path.join(os.path.dirname(__file__), 'synthetic_data')

DATA_PATH_Synth = os.path.join(os.path.dirname(__file__), 'data_synth')
FOLDS_PATH_Synth = os.path.join(os.path.dirname(__file__), 'folds_synth')


def download(url):
    name = url.split('/')[-1]
    download_path = os.path.join(DATA_PATH, name)

    if not os.path.exists(DATA_PATH):
        os.makedirs(DATA_PATH)

    if not os.path.exists(download_path):
        urlretrieve(url, download_path)

    if not os.path.exists(download_path.replace('.zip', '.dat')):
        if name.endswith('.zip'):
            with zipfile.ZipFile(download_path) as zip:
                zip.extractall(DATA_PATH)
        else:
            raise Exception('Unrecognized file type.')


def encode(X, y, encode_features=True):
    y = preprocessing.LabelEncoder().fit(y).transform(y)

    if np.sum(y==1) > np.sum(y==0):
        yTmp = np.ones(len(y))
        yTmp[np.where(y==1)[0]] = 0
        y    = yTmp

    if encode_features:
        encoded = []

        for i in range(X.shape[1]):
            try:
                float(X[0, i])
                encoded.append(X[:, i])
            except:
                encoded.append(preprocessing.LabelEncoder().fit_transform(X[:, i]))

        X = np.transpose(encoded)

    return X.astype(np.float32), y.astype(np.float32)


def partition(X, y, minSize=None):

    # rs = ShuffleSplit(n_splits=30, test_size=0.5)
    folds = []
    minCls = np.argmin(np.bincount(y.astype(int)))
    maxCls = np.argmax(np.bincount(y.astype(int)))

    rskf = RepeatedStratifiedKFold(n_splits=2, n_repeats=5, random_state=36851234)
    for train_idx, test_idx in rskf.split(X, y):
        minTrnInd = np.where(y[train_idx]==minCls)[0]
        majTrnInd = np.where(y[train_idx]==maxCls)[0]
        minTstInd = np.where(y[test_idx]==minCls)[0]
        majTstInd = np.where(y[test_idx]==maxCls)[0]
        if minSize is not None:
            subTrnInd = train_idx[np.random.choice(minTrnInd, np.min((len(minTrnInd), minSize)), replace=False)]
            subTrnInd = np.append(train_idx[majTrnInd], subTrnInd)
            subTstInd = test_idx[np.random.choice(minTstInd, np.min((len(minTstInd), minSize)), replace=False)]
            subTstInd = np.append(test_idx[majTstInd], subTstInd)
            folds.append([subTrnInd, subTstInd])

    return folds


def make_folds(X, y, partitions, scale=True):
    folds = []

    for i in range(len(partitions)):
            train_idx, test_idx = partitions[i]

            train_set = [X[train_idx].copy(), y[train_idx].copy()]
            test_set = [X[test_idx].copy(), y[test_idx].copy()]

            if scale:
                scaler = MinMaxScaler().fit(train_set[0])
                train_set[0] = scaler.transform(train_set[0])
                test_set[0] = scaler.transform(test_set[0])

            folds.append([train_set, test_set])

    return folds


def load(name, url=None, encode_features=True, remove_metadata=True, scale=True, noise_type=None, noise_level=0.0):
    assert noise_type in [None, 'class', 'attribute']
    assert 0.0 <= noise_level <= 1.0

    file_name = '%s.dat' % name

    if url is not None:
        download(url)

    skiprows = 0

    if remove_metadata:
        with open(os.path.join(DATA_PATH, file_name)) as f:
            for line in f:
                if line.startswith('@'):
                    skiprows += 1
                else:
                    break

    df = pd.read_csv(os.path.join(DATA_PATH, file_name), header=None, skiprows=skiprows, skipinitialspace=True,
                     sep=' *, *', na_values='?', engine='python')

    matrix = df.dropna().as_matrix()

    X, y = matrix[:, :-1], matrix[:, -1]
    X, y = encode(X, y, encode_features)

    partitions_path = os.path.join(FOLDS_PATH, file_name.replace('.dat', '.folds.pickle'))

    if not os.path.exists(FOLDS_PATH):
        os.mkdir(FOLDS_PATH)

    if os.path.exists(partitions_path):
        partitions = pickle.load(open(partitions_path, 'rb'))
    else:
        partitions = partition(X, y)
        pickle.dump(partitions, open(partitions_path, 'wb'))

    return make_folds(X, y, partitions, scale)

def loadSynth(name, url=None, encode_features=True, remove_metadata=True, scale=True, minSize=3):

    print(name)
    # file_name = '%s.dat' % name
    file_name = name

    if url is not None:
        download(url)

    skiprows = 0

    if remove_metadata:
        with open(os.path.join(DATA_PATH_Synth, file_name)) as f:
            for line in f:
                if line.startswith('@'):
                    skiprows += 1
                else:
                    break

    df = pd.read_csv(os.path.join(DATA_PATH_Synth, file_name), header=1, skiprows=skiprows, skipinitialspace=True,
                     sep=' *, *', na_values='?', engine='python')

    matrix = df.dropna().as_matrix()

    X, y = matrix[:, :-1], matrix[:, -1]
    minCls = np.argmin(np.bincount(y.astype(int)))
    maxCls = np.argmax(np.bincount(y.astype(int)))

    if minCls != 1:
        y[np.where(y==maxCls)] = 2
        y[np.where(y==minCls)] = 1
        y[np.where(y==2)] = 0

    X, y = encode(X, y, encode_features)

    partitions_path = os.path.join(FOLDS_PATH_Synth, file_name.replace('.dat', '.folds.pickle'))
    new_partitions_path = os.path.join(FOLDS_PATH_Synth, "Minsize"+str(minSize)+file_name.replace('.dat', '.folds.pickle'))
    if not os.path.exists(FOLDS_PATH_Synth):
        os.mkdir(FOLDS_PATH_Synth)

    if os.path.exists(partitions_path):
        partitions = pickle.load(open(new_partitions_path, 'rb'))
    else:
        partitions = partition(X, y, minSize)
        pickle.dump(partitions, open(new_partitions_path, 'wb'))

    return make_folds(X, y, partitions, scale)


def load_all(type=None,synth=1):
    assert type in [None, 'preliminary', 'final']

    urls = []

    for current_type in ['preliminary', 'final']:
        if type in [None, current_type]:
            with open(os.path.join(os.path.dirname(__file__), 'data_urls', '%s.txt' % current_type)) as file:
                for line in file.readlines():
                    urls.append(line.rstrip())

    datasets = {}

    for url in urls:
        name = url.split('/')[-1].replace('.zip', '')
        if synth==0:
            datasets[name] = load(name, url)
        else:
            for n_minority_train_samples in [60,50,40,30,20]:
                datasets[name] = loadSynth(name, url, minSize=n_minority_train_samples)
    return datasets


def names(type=None):
    assert type in [None, 'preliminary', 'final']

    urls = []

    for current_type in ['preliminary', 'final']:
        if type in [None, current_type]:
            with open(os.path.join(os.path.dirname(__file__), 'data_urls', '%s.txt' % current_type)) as file:
                for line in file.readlines():
                    urls.append(line.rstrip())

    return [url.split('/')[-1].replace('.zip', '') for url in urls]


def save_all_synthetic(n_majority_samples=1000):
    if not os.path.exists(SYNTHETIC_DATA_PATH):
        os.mkdir(SYNTHETIC_DATA_PATH)
        
    X, y = make_classification(int(2 * n_majority_samples * 1.05), 10)
    X, y = make_imbalance(X, y, {0: n_majority_samples, 1: int(n_majority_samples)})
    partitions = partition(X, y)
    folds = make_folds(X, y, partitions)

    for n_minority_train_samples in [60, 50, 40, 30, 20, 10]:
        print('Preparing "imbalance ratio = %s"...' % n_minority_train_samples)

        for i in range(5):
            (X_train, y_train), (X_test, y_test) = folds[i]
            n_minority_samples = int(np.where(y_train==1)[0]/2)
            X_train, y_train = make_imbalance(X_train, y_train, {
                0: int(n_majority_samples / 2), 1: n_minority_train_samples})
            X_test, y_test = make_imbalance(X_test, y_test, {
                0: int(n_majority_samples / 2), 1: n_minority_samples})
            folds[i] = (X_train, y_train), (X_test, y_test)

            print('Shapes: train %s, test %s.' % (X_train.shape, X_test.shape))
            print('Class distributions: train %s, test %s.' % (Counter(y_train), Counter(y_test)))

            y_train, y_test = np.reshape(y_train, (-1, 1)), np.reshape(y_test, (-1, 1))
            train_set, test_set = np.concatenate((X_train, y_train), axis=1), np.concatenate((X_test, y_test), axis=1)
            pd.DataFrame(train_set).to_csv(
                os.path.join(SYNTHETIC_DATA_PATH, 'imbalance_ratio_%d.%d.train.csv' % (imbalance_ratio, i + 1)),
                index=False)
            pd.DataFrame(test_set).to_csv(
                os.path.join(SYNTHETIC_DATA_PATH, 'imbalance_ratio_%d.%d.test.csv' % (imbalance_ratio, i + 1)),
                index=False)

def load_synthetic(type, parameter, fold):
    assert type in ['n_features', 'imbalance_ratio']
    assert 1 <= fold <= 30

    matrix = pd.read_csv(os.path.join(SYNTHETIC_DATA_PATH, '%s_%d.%d.train.csv' % (type, parameter, fold))).as_matrix()
    X_train, y_train = matrix[:, :-1], matrix[:, -1]

    matrix = pd.read_csv(os.path.join(SYNTHETIC_DATA_PATH, '%s_%d.%d.test.csv' % (type, parameter, fold))).as_matrix()
    X_test, y_test = matrix[:, :-1], matrix[:, -1]

    return X_train, y_train, X_test, y_test


if __name__ == '__main__':
    load_all(type="final",synth=1)
